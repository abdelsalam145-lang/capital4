<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * جدول الفواتير: قد تنشأ من عقد (دورية) أو من طلب صيانة منفرد.
 * تُحسب القيم: الإجمالي قبل الضريبة + الضريبة (15%) = الإجمالي النهائي.
 */
return new class extends Migration {
    public function up(): void
    {
        Schema::create('invoices', function (Blueprint $table) {
            $table->id();

            // رقم الفاتورة المقروء مثل: INV-2024-00001
            $table->string('reference')->unique();

            $table->foreignId('customer_id')->constrained('customers');

            // مصدر الفاتورة (أحدهما أو لا شيء لفاتورة يدوية)
            $table->foreignId('contract_id')->nullable()->constrained('contracts')->nullOnDelete();
            $table->foreignId('maintenance_request_id')->nullable()
                  ->constrained('maintenance_requests')->nullOnDelete();

            $table->date('issue_date');
            $table->date('due_date');

            // القيم المالية (تُحسب من البنود)
            $table->decimal('subtotal', 12, 2)->default(0);       // قبل الضريبة
            $table->decimal('tax_rate', 5, 2)->default(15.00);    // نسبة الضريبة %
            $table->decimal('tax_amount', 12, 2)->default(0);     // مبلغ الضريبة
            $table->decimal('discount', 12, 2)->default(0);       // خصم
            $table->decimal('total', 12, 2)->default(0);          // الإجمالي النهائي
            $table->decimal('amount_paid', 12, 2)->default(0);    // المدفوع حتى الآن

            // الحالة
            $table->enum('status', ['draft', 'unpaid', 'partially_paid', 'paid', 'overdue', 'cancelled'])
                  ->default('draft')
                  ->index();

            $table->string('currency', 3)->default('SAR');
            $table->text('notes')->nullable();

            $table->timestamps();
            $table->softDeletes();
        });

        // بنود الفاتورة
        Schema::create('invoice_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('invoice_id')->constrained('invoices')->cascadeOnDelete();
            $table->string('description');
            $table->decimal('quantity', 10, 2)->default(1);
            $table->decimal('unit_price', 12, 2)->default(0);
            $table->decimal('line_total', 12, 2)->default(0);   // quantity * unit_price
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('invoice_items');
        Schema::dropIfExists('invoices');
    }
};
