<?php

namespace App\Http\Controllers;

use App\Models\Warehouse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class WarehouseController extends Controller
{
    public function index()
    {
        abort_unless(Auth::user()->canManageRequests() || Auth::user()->isTechnician(), 403);
        return response()->json(Warehouse::where('is_active', true)->with('technician')->get());
    }

    public function store(Request $request)
    {
        abort_unless(Auth::user()->canManageRequests(), 403);

        $data = $request->validate([
            'name'          => 'required|string|max:255',
            'type'          => 'required|in:main,technician,branch',
            'technician_id' => 'nullable|exists:users,id',
            'location'      => 'nullable|string',
        ]);

        return response()->json(Warehouse::create($data), 201);
    }
}
