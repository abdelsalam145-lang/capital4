<?php

namespace App\Http\Controllers;

use App\Models\MaintenanceRequest;
use App\Models\Part;
use App\Models\Warehouse;
use App\Services\InventoryService;
use App\Services\InvoiceService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PartUsageController extends Controller
{
    public function __construct(
        private InventoryService $inventory,
        private InvoiceService $invoices
    ) {}

    /** عرض القطع المستخدمة في طلب */
    public function index(MaintenanceRequest $maintenanceRequest)
    {
        return response()->json(
            $maintenanceRequest->partUsages()->with('part')->get()
        );
    }

    /**
     * الفني يسجّل استهلاك قطعة في الطلب المسند إليه.
     * يُخصم تلقائياً من المخزون المحدد.
     */
    public function store(Request $request, MaintenanceRequest $maintenanceRequest)
    {
        $tech = Auth::user();

        // الفني المسند فقط (أو المدير/المشرف)
        $allowed = $tech->canManageRequests()
            || $maintenanceRequest->assigned_technician_id === $tech->id;
        abort_unless($allowed, 403);

        $data = $request->validate([
            'part_id'      => 'required|exists:parts,id',
            'warehouse_id' => 'required|exists:warehouses,id',
            'quantity'     => 'required|numeric|min:0.01',
            'unit_price'   => 'nullable|numeric|min:0',
        ]);

        $usage = $this->inventory->consumeForRequest(
            $maintenanceRequest,
            Part::findOrFail($data['part_id']),
            Warehouse::findOrFail($data['warehouse_id']),
            $data['quantity'],
            $tech,
            $data['unit_price'] ?? null
        );

        return response()->json($usage->load('part'), 201);
    }

    /**
     * فوترة القطع المستخدمة في الطلب (غير المفوترة بعد) كبنود في فاتورة جديدة.
     * مفيد لطلبات الإصلاح خارج العقد.
     */
    public function bill(MaintenanceRequest $maintenanceRequest)
    {
        abort_unless(Auth::user()->canManageRequests(), 403);

        $usages = $maintenanceRequest->partUsages()->where('billed', false)->with('part')->get();

        abort_if($usages->isEmpty(), 422, 'لا توجد قطع غير مفوترة لهذا الطلب.');

        return DB::transaction(function () use ($maintenanceRequest, $usages) {
            $items = $usages->map(fn ($u) => [
                'description' => "قطعة: {$u->part->name} (كود {$u->part->sku})",
                'quantity'    => $u->quantity,
                'unit_price'  => $u->unit_price,
            ])->all();

            $invoice = $this->invoices->create([
                'customer_id'            => $maintenanceRequest->customer_id,
                'maintenance_request_id' => $maintenanceRequest->id,
                'notes'                  => "فاتورة قطع غيار للطلب {$maintenanceRequest->reference}",
            ], $items);

            // تعليم القطع كمفوترة
            $maintenanceRequest->partUsages()->whereIn('id', $usages->pluck('id'))
                ->update(['billed' => true]);

            return response()->json($this->invoices->issue($invoice)->load('items'), 201);
        });
    }
}
