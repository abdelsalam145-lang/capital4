<?php

namespace App\Http\Controllers;

use App\Models\MaintenanceRequest;
use App\Models\User;
use App\Services\RequestService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class MaintenanceRequestController extends Controller
{
    public function __construct(private RequestService $service) {}

    /**
     * عرض الطلبات حسب دور المستخدم:
     * - المدير/المشرف: كل الطلبات.
     * - الفني: الطلبات المسندة إليه فقط.
     * - العميل: طلبات حسابه فقط.
     */
    public function index(Request $request)
    {
        $user = Auth::user();
        $query = MaintenanceRequest::query()
            ->with(['elevator.building', 'customer', 'technician'])
            ->latest();

        if ($user->isTechnician()) {
            $query->forTechnician($user->id);
        } elseif ($user->isCustomer()) {
            $query->forCustomer($user->customer_id);
        }

        // فلاتر اختيارية
        if ($request->filled('status'))   $query->where('status', $request->status);
        if ($request->filled('type'))     $query->where('type', $request->type);
        if ($request->filled('priority')) $query->where('priority', $request->priority);

        return response()->json($query->paginate(20));
    }

    public function show(MaintenanceRequest $maintenanceRequest)
    {
        $this->authorizeView($maintenanceRequest);

        return response()->json(
            $maintenanceRequest->load([
                'elevator.building', 'customer', 'creator',
                'technician', 'statusLogs.user', 'attachments', 'rating',
            ])
        );
    }

    /** إنشاء طلب (عميل أو موظف) */
    public function store(Request $request)
    {
        $data = $request->validate([
            'type'        => 'required|in:maintenance,fault,inspection',
            'elevator_id' => 'required|exists:elevators,id',
            'title'       => 'required|string|max:255',
            'description' => 'nullable|string',
            'priority'    => 'nullable|in:low,normal,high,urgent',
        ]);

        $newRequest = $this->service->create($data, Auth::user());

        return response()->json($newRequest, 201);
    }

    /** تعيين فني (المدير أو المشرفون) */
    public function assign(Request $request, MaintenanceRequest $maintenanceRequest)
    {
        $data = $request->validate([
            'technician_id' => 'required|exists:users,id',
            'scheduled_at'  => 'nullable|date',
        ]);

        $technician = User::findOrFail($data['technician_id']);

        $updated = $this->service->assignTechnician(
            $maintenanceRequest, $technician, Auth::user(), $data['scheduled_at'] ?? null
        );

        return response()->json($updated);
    }

    /** الفني يبدأ العمل */
    public function start(MaintenanceRequest $maintenanceRequest)
    {
        return response()->json(
            $this->service->start($maintenanceRequest, Auth::user())
        );
    }

    /** الفني ينهي العمل */
    public function complete(Request $request, MaintenanceRequest $maintenanceRequest)
    {
        $data = $request->validate(['resolution_notes' => 'nullable|string']);

        return response()->json(
            $this->service->complete($maintenanceRequest, Auth::user(), $data['resolution_notes'] ?? null)
        );
    }

    /** إلغاء الطلب */
    public function cancel(Request $request, MaintenanceRequest $maintenanceRequest)
    {
        $data = $request->validate(['reason' => 'required|string']);

        return response()->json(
            $this->service->cancel($maintenanceRequest, Auth::user(), $data['reason'])
        );
    }

    /** حماية: العميل لا يرى إلا طلباته، والفني إلا المسند إليه */
    private function authorizeView(MaintenanceRequest $req): void
    {
        $user = Auth::user();
        if ($user->isCustomer() && $req->customer_id !== $user->customer_id) abort(403);
        if ($user->isTechnician() && $req->assigned_technician_id !== $user->id) abort(403);
    }
}
