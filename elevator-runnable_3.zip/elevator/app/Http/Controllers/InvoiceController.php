<?php

namespace App\Http\Controllers;

use App\Models\Contract;
use App\Models\Invoice;
use App\Services\InvoiceService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class InvoiceController extends Controller
{
    public function __construct(private InvoiceService $service) {}

    /** المدير/المشرف: كل الفواتير. العميل: فواتيره فقط */
    public function index(Request $request)
    {
        $user = Auth::user();
        $query = Invoice::with(['customer', 'contract'])->latest();

        if ($user->isCustomer()) {
            $query->where('customer_id', $user->customer_id);
        }
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        // العميل غالباً يريد فواتيره غير المسدّدة
        if ($request->boolean('unpaid_only')) {
            $query->unpaid();
        }

        return response()->json($query->paginate(20));
    }

    public function show(Invoice $invoice)
    {
        $this->authorizeView($invoice);
        return response()->json($invoice->load(['items', 'payments', 'customer', 'contract']));
    }

    /** إنشاء فاتورة يدوية (موظفون) */
    public function store(Request $request)
    {
        abort_unless(Auth::user()->canManageRequests(), 403);

        $data = $request->validate([
            'customer_id'            => 'required|exists:customers,id',
            'contract_id'            => 'nullable|exists:contracts,id',
            'maintenance_request_id' => 'nullable|exists:maintenance_requests,id',
            'issue_date'             => 'nullable|date',
            'due_date'               => 'nullable|date',
            'discount'               => 'nullable|numeric|min:0',
            'items'                  => 'required|array|min:1',
            'items.*.description'    => 'required|string',
            'items.*.quantity'       => 'required|numeric|min:0',
            'items.*.unit_price'     => 'required|numeric|min:0',
        ]);

        $invoice = $this->service->create($data, $data['items']);
        return response()->json($invoice->load('items'), 201);
    }

    /** توليد فاتورة دورية من عقد */
    public function generateFromContract(Contract $contract)
    {
        abort_unless(Auth::user()->canManageRequests(), 403);
        $invoice = $this->service->generateFromContract($contract);
        return response()->json($invoice->load('items'), 201);
    }

    /** اعتماد المسودّة */
    public function issue(Invoice $invoice)
    {
        abort_unless(Auth::user()->canManageRequests(), 403);
        return response()->json($this->service->issue($invoice));
    }

    private function authorizeView(Invoice $invoice): void
    {
        $user = Auth::user();
        if ($user->isCustomer() && $invoice->customer_id !== $user->customer_id) abort(403);
    }
}
