<?php

namespace App\Http\Controllers;

use App\Models\Part;
use App\Models\Warehouse;
use App\Services\InventoryService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PartController extends Controller
{
    public function __construct(private InventoryService $inventory) {}

    /** كتالوج القطع. فلتر low_stock=1 لعرض ما يحتاج إعادة طلب */
    public function index(Request $request)
    {
        abort_unless(Auth::user()->canManageRequests() || Auth::user()->isTechnician(), 403);

        $query = Part::query()->where('is_active', true);

        if ($request->filled('search')) {
            $query->where(fn ($q) => $q
                ->where('name', 'like', "%{$request->search}%")
                ->orWhere('sku', 'like', "%{$request->search}%"));
        }
        if ($request->boolean('low_stock')) {
            $query->lowStock();
        }
        if ($request->filled('category')) {
            $query->where('category', $request->category);
        }

        return response()->json($query->orderBy('name')->paginate(30));
    }

    public function show(Part $part)
    {
        return response()->json($part->load(['stocks.warehouse']));
    }

    /** إضافة قطعة للكتالوج (موظفون) */
    public function store(Request $request)
    {
        abort_unless(Auth::user()->canManageRequests(), 403);

        $data = $request->validate([
            'sku'           => 'required|string|unique:parts,sku',
            'name'          => 'required|string|max:255',
            'brand'         => 'nullable|string',
            'category'      => 'nullable|string',
            'unit'          => 'nullable|string',
            'cost_price'    => 'nullable|numeric|min:0',
            'sale_price'    => 'nullable|numeric|min:0',
            'reorder_level' => 'nullable|numeric|min:0',
        ]);

        return response()->json(Part::create($data), 201);
    }

    public function update(Request $request, Part $part)
    {
        abort_unless(Auth::user()->canManageRequests(), 403);

        $data = $request->validate([
            'name'          => 'sometimes|string|max:255',
            'cost_price'    => 'sometimes|numeric|min:0',
            'sale_price'    => 'sometimes|numeric|min:0',
            'reorder_level' => 'sometimes|numeric|min:0',
            'is_active'     => 'sometimes|boolean',
        ]);

        $part->update($data);
        return response()->json($part->fresh());
    }

    /** إدخال مخزون (توريد) */
    public function receive(Request $request, Part $part)
    {
        abort_unless(Auth::user()->canManageRequests(), 403);

        $data = $request->validate([
            'warehouse_id' => 'required|exists:warehouses,id',
            'quantity'     => 'required|numeric|min:0.01',
            'unit_cost'    => 'nullable|numeric|min:0',
            'note'         => 'nullable|string',
        ]);

        $movement = $this->inventory->receive(
            $part, Warehouse::findOrFail($data['warehouse_id']),
            $data['quantity'], Auth::user(), $data['unit_cost'] ?? null, $data['note'] ?? null
        );

        return response()->json($movement, 201);
    }

    /** تسوية جرد */
    public function adjust(Request $request, Part $part)
    {
        abort_unless(Auth::user()->canManageRequests(), 403);

        $data = $request->validate([
            'warehouse_id' => 'required|exists:warehouses,id',
            'counted_qty'  => 'required|numeric|min:0',
            'note'         => 'nullable|string',
        ]);

        $movement = $this->inventory->adjust(
            $part, Warehouse::findOrFail($data['warehouse_id']),
            $data['counted_qty'], Auth::user(), $data['note'] ?? null
        );

        return response()->json($movement);
    }

    /** تحويل بين مستودعين */
    public function transfer(Request $request, Part $part)
    {
        abort_unless(Auth::user()->canManageRequests(), 403);

        $data = $request->validate([
            'from_warehouse_id' => 'required|exists:warehouses,id',
            'to_warehouse_id'   => 'required|different:from_warehouse_id|exists:warehouses,id',
            'quantity'          => 'required|numeric|min:0.01',
            'note'              => 'nullable|string',
        ]);

        $this->inventory->transfer(
            $part,
            Warehouse::findOrFail($data['from_warehouse_id']),
            Warehouse::findOrFail($data['to_warehouse_id']),
            $data['quantity'], Auth::user(), $data['note'] ?? null
        );

        return response()->json(['status' => 'ok']);
    }

    /** سجل حركات القطعة */
    public function movements(Part $part)
    {
        abort_unless(Auth::user()->canManageRequests(), 403);
        return response()->json(
            $part->movements()->with('warehouse')->latest()->paginate(50)
        );
    }
}
