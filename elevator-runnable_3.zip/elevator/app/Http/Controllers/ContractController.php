<?php

namespace App\Http\Controllers;

use App\Models\Contract;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ContractController extends Controller
{
    /** المدير/المشرف يرى كل العقود، العميل يرى عقوده فقط */
    public function index(Request $request)
    {
        $user = Auth::user();
        $query = Contract::with(['customer', 'elevators'])->latest();

        if ($user->isCustomer()) {
            $query->where('customer_id', $user->customer_id);
        }
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        return response()->json($query->paginate(20));
    }

    public function show(Contract $contract)
    {
        $this->authorizeView($contract);
        return response()->json($contract->load(['customer', 'elevators', 'invoices']));
    }

    /** إنشاء عقد (موظفون فقط) */
    public function store(Request $request)
    {
        abort_unless(Auth::user()->canManageRequests(), 403);

        $data = $request->validate([
            'customer_id'      => 'required|exists:customers,id',
            'type'             => 'required|in:full_maintenance,preventive,on_call,warranty',
            'value'            => 'required|numeric|min:0',
            'billing_cycle'    => 'required|in:monthly,quarterly,semi_annual,annual',
            'visits_per_cycle' => 'nullable|integer|min:0',
            'start_date'       => 'required|date',
            'end_date'         => 'required|date|after:start_date',
            'auto_renew'       => 'boolean',
            'elevator_ids'     => 'array',
            'elevator_ids.*'   => 'exists:elevators,id',
            'terms'            => 'nullable|string',
        ]);

        $contract = Contract::create($data);
        if (! empty($data['elevator_ids'])) {
            $contract->elevators()->sync($data['elevator_ids']);
        }

        return response()->json($contract->load('elevators'), 201);
    }

    public function update(Request $request, Contract $contract)
    {
        abort_unless(Auth::user()->canManageRequests(), 403);

        $data = $request->validate([
            'status'       => 'sometimes|in:draft,active,expired,cancelled,suspended',
            'value'        => 'sometimes|numeric|min:0',
            'end_date'     => 'sometimes|date',
            'auto_renew'   => 'sometimes|boolean',
            'elevator_ids' => 'sometimes|array',
        ]);

        $contract->update($data);
        if (isset($data['elevator_ids'])) {
            $contract->elevators()->sync($data['elevator_ids']);
        }

        return response()->json($contract->fresh()->load('elevators'));
    }

    private function authorizeView(Contract $contract): void
    {
        $user = Auth::user();
        if ($user->isCustomer() && $contract->customer_id !== $user->customer_id) abort(403);
    }
}
