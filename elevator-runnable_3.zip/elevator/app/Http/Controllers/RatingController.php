<?php

namespace App\Http\Controllers;

use App\Models\MaintenanceRequest;
use App\Models\TechnicianRating;
use App\Services\RequestService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class RatingController extends Controller
{
    public function __construct(private RequestService $service) {}

    /**
     * العميل يقيّم الفني بعد إنهاء الطلب.
     * بعد حفظ التقييم يُغلق الطلب تلقائياً (closed).
     */
    public function store(Request $request, MaintenanceRequest $maintenanceRequest)
    {
        $user = Auth::user();

        // حماية: فقط عميل الطلب يمكنه التقييم، والطلب يجب أن يكون مكتملاً
        abort_unless($user->isCustomer() && $maintenanceRequest->customer_id === $user->customer_id, 403);
        abort_unless($maintenanceRequest->status === 'completed', 422, 'الطلب غير جاهز للتقييم.');
        abort_if($maintenanceRequest->rating()->exists(), 422, 'تم التقييم مسبقاً.');

        $data = $request->validate([
            'rating'  => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string|max:1000',
        ]);

        $rating = TechnicianRating::create([
            'maintenance_request_id' => $maintenanceRequest->id,
            'technician_id'          => $maintenanceRequest->assigned_technician_id,
            'customer_id'            => $maintenanceRequest->customer_id,
            'rating'                 => $data['rating'],
            'comment'                => $data['comment'] ?? null,
        ]);

        // إغلاق الطلب بعد التقييم
        $this->service->close($maintenanceRequest, $user);

        return response()->json($rating, 201);
    }
}
