<?php

namespace App\Http\Controllers;

use App\Services\DashboardService;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function __construct(private DashboardService $dashboard) {}

    /**
     * لوحة المؤشرات الكاملة (للمدير والمشرفين فقط).
     * تُرجع كل البيانات في استجابة واحدة لتغذية الواجهة.
     */
    public function index()
    {
        abort_unless(Auth::user()->canManageRequests(), 403);

        return response()->json([
            'overview'             => $this->dashboard->overview(),
            'requests_by_status'   => $this->dashboard->requestsByStatus(),
            'requests_by_type'     => $this->dashboard->requestsByType(),
            'requests_trend'       => $this->dashboard->requestsTrend(),
            'revenue_trend'        => $this->dashboard->revenueTrend(),
            'financial_summary'    => $this->dashboard->financialSummary(),
            'problematic_elevators'=> $this->dashboard->topProblematicElevators(),
            'technician_performance'=> $this->dashboard->technicianPerformance(),
            'top_consumed_parts'   => $this->dashboard->topConsumedParts(),
            'low_stock_parts'      => $this->dashboard->lowStockParts(),
        ]);
    }

    /** بطاقات النظرة العامة فقط (تحديث سريع متكرر) */
    public function overview()
    {
        abort_unless(Auth::user()->canManageRequests(), 403);
        return response()->json($this->dashboard->overview());
    }
}
