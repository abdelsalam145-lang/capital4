<?php

namespace App\Http\Controllers;

use App\Models\Invoice;
use App\Models\Payment;
use App\Services\PaymentService;
use App\Services\Payments\MoyasarGateway;
use App\Services\Payments\PaymentGateway;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PaymentController extends Controller
{
    public function __construct(private PaymentService $service) {}

    /**
     * تسجيل دفعة يدوية (نقدي/تحويل/شيك) — موظفون فقط.
     */
    public function recordManual(Request $request, Invoice $invoice)
    {
        abort_unless(Auth::user()->canManageRequests(), 403);

        $data = $request->validate([
            'amount' => 'required|numeric|min:0.01',
            'method' => 'required|in:cash,bank_transfer,cheque,card',
            'notes'  => 'nullable|string',
        ]);

        $payment = $this->service->recordManual($invoice, $data, Auth::user());
        return response()->json($payment, 201);
    }

    /**
     * بدء دفعة إلكترونية — العميل يدفع فاتورته من البوابة.
     * يُعيد رابط الدفع الذي يُفتح في الويب أو الجوال.
     */
    public function payOnline(Request $request, Invoice $invoice)
    {
        $user = Auth::user();
        // العميل يدفع فواتيره فقط (والموظف يستطيع أيضاً)
        if ($user->isCustomer()) {
            abort_unless($invoice->customer_id === $user->customer_id, 403);
        }

        $data = $request->validate([
            'amount' => 'nullable|numeric|min:0.01', // افتراضياً كامل المتبقّي
        ]);

        $amount   = $data['amount'] ?? $invoice->balance();
        $gateway  = $this->gateway($request->input('gateway', 'moyasar'));
        $callback = route('payments.callback'); // صفحة العودة بعد الدفع

        $result = $this->service->initiateOnline($invoice, $amount, $gateway, $callback);
        return response()->json($result);
    }

    /**
     * عودة العميل من البوابة / استقبال webhook للتأكيد.
     */
    public function callback(Request $request)
    {
        $payment = Payment::where('gateway_payment_id', $request->input('id'))
            ->orWhere('id', $request->input('payment_id'))
            ->firstOrFail();

        $gateway = $this->gateway($payment->gateway ?? 'moyasar');
        $confirmed = $this->service->confirmOnline($payment, $gateway);

        return response()->json([
            'status'  => $confirmed->status,
            'invoice' => $confirmed->invoice->fresh(),
        ]);
    }

    /** اختيار البوابة المناسبة (قابل للتوسعة لـ Tap/PayTabs) */
    private function gateway(string $name): PaymentGateway
    {
        return match ($name) {
            'moyasar' => app(MoyasarGateway::class),
            default   => app(MoyasarGateway::class),
        };
    }
}
