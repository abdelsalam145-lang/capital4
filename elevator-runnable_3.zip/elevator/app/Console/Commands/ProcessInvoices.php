<?php

namespace App\Console\Commands;

use App\Models\Contract;
use App\Models\Invoice;
use App\Services\InvoiceService;
use Illuminate\Console\Command;

/**
 * أمر مجدول يومي:
 *  1) يعلّم الفواتير غير المسدّدة المتأخرة عن موعدها بـ overdue.
 *  2) يولّد فواتير دورية جديدة للعقود الفعّالة عند حلول موعد الدورة.
 *
 * يُجدول في bootstrap/app.php أو routes/console.php:
 *   Schedule::command('invoices:process')->dailyAt('02:00');
 */
class ProcessInvoices extends Command
{
    protected $signature = 'invoices:process';
    protected $description = 'تعليم الفواتير المتأخرة وتوليد الفواتير الدورية للعقود';

    public function handle(InvoiceService $invoices): int
    {
        // 1) الفواتير المتأخرة
        $overdue = Invoice::whereIn('status', ['unpaid', 'partially_paid'])
            ->whereDate('due_date', '<', now())
            ->update(['status' => 'overdue']);
        $this->info("تم تعليم {$overdue} فاتورة كمتأخرة.");

        // 2) توليد الفواتير الدورية
        $generated = 0;
        $activeContracts = Contract::where('status', 'active')
            ->whereDate('start_date', '<=', now())
            ->whereDate('end_date', '>=', now())
            ->get();

        foreach ($activeContracts as $contract) {
            if ($this->isDueForInvoice($contract)) {
                $invoices->generateFromContract($contract);
                $generated++;
            }
        }
        $this->info("تم توليد {$generated} فاتورة دورية.");

        return self::SUCCESS;
    }

    /**
     * هل حان موعد توليد فاتورة جديدة لهذا العقد؟
     * منطق مبسّط: لا توجد فاتورة خلال آخر دورة فوترة.
     */
    private function isDueForInvoice(Contract $contract): bool
    {
        $lastInvoice = $contract->invoices()->latest('issue_date')->first();

        if (! $lastInvoice) {
            return true; // لم تصدر أي فاتورة بعد
        }

        $nextDue = $lastInvoice->issue_date->copy()->addMonths($contract->cycleMonths());
        return now()->gte($nextDue);
    }
}
