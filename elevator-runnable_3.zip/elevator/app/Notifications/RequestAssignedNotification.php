<?php

namespace App\Notifications;

use App\Models\MaintenanceRequest;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

/** إشعار للفني عند إسناد طلب إليه */
class RequestAssignedNotification extends Notification
{
    use Queueable;

    public function __construct(public MaintenanceRequest $request) {}

    public function via($notifiable): array
    {
        return ['database']; // أضِف 'fcm' للجوال
    }

    public function toArray($notifiable): array
    {
        return [
            'request_id' => $this->request->id,
            'reference'  => $this->request->reference,
            'title'      => $this->request->title,
            'message'    => 'تم إسناد طلب جديد إليك',
        ];
    }
}
