<?php

namespace App\Notifications;

use App\Models\MaintenanceRequest;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;

/** إشعار للمدير والمشرفين عند ورود طلب جديد */
class NewRequestNotification extends Notification
{
    use Queueable;

    public function __construct(public MaintenanceRequest $request) {}

    // database = إشعار داخل التطبيق، mail = بريد. أضِف 'fcm' للجوال لاحقاً.
    public function via($notifiable): array
    {
        return ['database', 'mail'];
    }

    public function toMail($notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject("طلب جديد: {$this->request->reference}")
            ->line("ورد طلب {$this->request->type} جديد من العميل.")
            ->line("العنوان: {$this->request->title}")
            ->action('عرض الطلب', url("/requests/{$this->request->id}"));
    }

    public function toArray($notifiable): array
    {
        return [
            'request_id' => $this->request->id,
            'reference'  => $this->request->reference,
            'type'       => $this->request->type,
            'title'      => $this->request->title,
            'message'    => 'طلب جديد بانتظار التعيين',
        ];
    }
}
