<?php

namespace App\Notifications;

use App\Models\MaintenanceRequest;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

/** إشعار للعميل عند إنهاء الطلب لطلب تقييم الفني */
class RequestCompletedNotification extends Notification
{
    use Queueable;

    public function __construct(public MaintenanceRequest $request) {}

    public function via($notifiable): array
    {
        return ['database', 'mail'];
    }

    public function toArray($notifiable): array
    {
        return [
            'request_id' => $this->request->id,
            'reference'  => $this->request->reference,
            'message'    => 'تم إنهاء طلبك. يرجى تقييم الفني.',
            'action'     => 'rate',
        ];
    }
}
