<?php

namespace App\Notifications;

use App\Models\Part;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;

/** تنبيه المدير/المشرفين عند وصول قطعة لحد إعادة الطلب */
class LowStockNotification extends Notification
{
    use Queueable;

    public function __construct(public Part $part) {}

    public function via($notifiable): array
    {
        return ['database', 'mail'];
    }

    public function toMail($notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject("تنبيه مخزون منخفض: {$this->part->name}")
            ->line("القطعة {$this->part->name} (كود {$this->part->sku}) وصلت لحد إعادة الطلب.")
            ->line("المتاح: {$this->part->quantity_on_hand} | حد إعادة الطلب: {$this->part->reorder_level}");
    }

    public function toArray($notifiable): array
    {
        return [
            'part_id'  => $this->part->id,
            'sku'      => $this->part->sku,
            'name'     => $this->part->name,
            'on_hand'  => $this->part->quantity_on_hand,
            'message'  => 'مخزون منخفض — يلزم إعادة الطلب',
        ];
    }
}
