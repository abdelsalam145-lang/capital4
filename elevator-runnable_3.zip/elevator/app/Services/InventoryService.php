<?php

namespace App\Services;

use App\Models\Part;
use App\Models\PartStock;
use App\Models\PartUsage;
use App\Models\StockMovement;
use App\Models\Warehouse;
use App\Models\MaintenanceRequest;
use App\Models\User;
use App\Notifications\LowStockNotification;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * خدمة المخزون: نقطة الدخول الوحيدة لأي تغيير في الكميات.
 * كل عملية تُسجَّل كحركة (StockMovement) وتحدّث:
 *   - رصيد القطعة في المستودع (part_stocks)
 *   - الكمية الإجمالية للقطعة (parts.quantity_on_hand)
 * ضمن معاملة واحدة مع قفل صفّي لمنع التضارب عند التزامن.
 */
class InventoryService
{
    /**
     * إدخال مخزون (شراء/توريد). كمية موجبة.
     */
    public function receive(Part $part, Warehouse $warehouse, float $qty, User $actor, ?float $unitCost = null, ?string $note = null): StockMovement
    {
        $this->assertPositive($qty);

        return $this->applyMovement(
            $part, $warehouse, abs($qty), 'purchase', $actor,
            unitCost: $unitCost ?? $part->cost_price,
            note: $note,
        );
    }

    /**
     * تسوية جرد: تضبط الكمية الفعلية في مستودع لقيمة محددة،
     * وتسجّل الفرق كحركة adjustment (قد تكون موجبة أو سالبة).
     */
    public function adjust(Part $part, Warehouse $warehouse, float $countedQty, User $actor, ?string $note = null): StockMovement
    {
        return DB::transaction(function () use ($part, $warehouse, $countedQty, $actor, $note) {
            $stock = $this->lockedStock($part, $warehouse);
            $diff  = round($countedQty - (float) $stock->quantity, 2);

            return $this->applyMovement(
                $part, $warehouse, $diff, 'adjustment', $actor,
                note: $note ?? 'تسوية جرد',
            );
        });
    }

    /**
     * تحويل بين مستودعين (مثلاً من المخزن الرئيسي لمخزون فني).
     */
    public function transfer(Part $part, Warehouse $from, Warehouse $to, float $qty, User $actor, ?string $note = null): void
    {
        $this->assertPositive($qty);

        DB::transaction(function () use ($part, $from, $to, $qty, $actor, $note) {
            $this->applyMovement($part, $from, -abs($qty), 'transfer_out', $actor, note: $note);
            $this->applyMovement($part, $to,   abs($qty),  'transfer_in',  $actor, note: $note);
        });
    }

    /**
     * استهلاك قطعة ضمن طلب صيانة: يخصمها من مخزون الفني (أو المخزن المحدد)،
     * ويسجّل استخدامها (PartUsage) تمهيداً لإضافتها لفاتورة الإصلاح.
     */
    public function consumeForRequest(
        MaintenanceRequest $request,
        Part $part,
        Warehouse $warehouse,
        float $qty,
        User $technician,
        ?float $unitPrice = null
    ): PartUsage {
        $this->assertPositive($qty);

        return DB::transaction(function () use ($request, $part, $warehouse, $qty, $technician, $unitPrice) {
            $stock = $this->lockedStock($part, $warehouse);

            if ((float) $stock->quantity < $qty) {
                throw ValidationException::withMessages([
                    'quantity' => "الكمية المتاحة في {$warehouse->name} ({$stock->quantity}) أقل من المطلوب ({$qty}).",
                ]);
            }

            // الخصم عبر حركة استهلاك مربوطة بالطلب
            $movement = $this->applyMovement(
                $part, $warehouse, -abs($qty), 'consumption', $technician,
                reference: $request,
                note: "استهلاك في الطلب {$request->reference}",
            );

            // تسجيل الاستخدام للفوترة لاحقاً
            $usage = PartUsage::create([
                'maintenance_request_id' => $request->id,
                'part_id'                => $part->id,
                'warehouse_id'           => $warehouse->id,
                'used_by'                => $technician->id,
                'quantity'               => $qty,
                'unit_price'             => $unitPrice ?? $part->sale_price,
            ]);

            return $usage->fresh();
        });
    }

    /**
     * إرجاع قطعة للمخزون (مثلاً لم تُستخدم فعلاً).
     */
    public function returnStock(Part $part, Warehouse $warehouse, float $qty, User $actor, ?string $note = null): StockMovement
    {
        $this->assertPositive($qty);
        return $this->applyMovement($part, $warehouse, abs($qty), 'return', $actor, note: $note);
    }

    // ===== المحرّك الداخلي =====

    /**
     * تطبيق حركة واحدة على المخزون (موجبة = إدخال، سالبة = إخراج).
     * يحدّث رصيد المستودع والكمية الإجمالية ويسجّل الحركة،
     * ويطلق تنبيه انخفاض المخزون عند الحاجة.
     */
    private function applyMovement(
        Part $part,
        Warehouse $warehouse,
        float $signedQty,
        string $type,
        User $actor,
        ?float $unitCost = null,
        $reference = null,
        ?string $note = null
    ): StockMovement {
        return DB::transaction(function () use ($part, $warehouse, $signedQty, $type, $actor, $unitCost, $reference, $note) {
            $stock = $this->lockedStock($part, $warehouse);

            $newWarehouseQty = round((float) $stock->quantity + $signedQty, 2);
            if ($newWarehouseQty < 0) {
                throw ValidationException::withMessages([
                    'quantity' => 'لا يمكن أن يصبح رصيد المستودع سالباً.',
                ]);
            }

            // تحديث رصيد المستودع
            $stock->update(['quantity' => $newWarehouseQty]);

            // تحديث الكمية الإجمالية للقطعة كمجموع فعلي لكل المستودعات
            // (أدق من الزيادة الحسابية ويمنع أي انحراف عند التزامن)
            $totalOnHand = round((float) PartStock::where('part_id', $part->id)->sum('quantity'), 2);
            $part->forceFill(['quantity_on_hand' => $totalOnHand])->save();

            // تسجيل الحركة
            $movement = StockMovement::create([
                'part_id'        => $part->id,
                'warehouse_id'   => $warehouse->id,
                'type'           => $type,
                'quantity'       => $signedQty,
                'balance_after'  => $newWarehouseQty,
                'unit_cost'      => $unitCost,
                'reference_type' => $reference ? get_class($reference) : null,
                'reference_id'   => $reference?->id,
                'performed_by'   => $actor->id,
                'note'           => $note,
            ]);

            // تنبيه انخفاض المخزون
            if ($part->isLowStock()) {
                $this->notifyLowStock($part);
            }

            return $movement;
        });
    }

    /**
     * جلب/إنشاء رصيد القطعة في المستودع مع قفل الصف لمنع التضارب.
     */
    private function lockedStock(Part $part, Warehouse $warehouse): PartStock
    {
        $stock = PartStock::where('part_id', $part->id)
            ->where('warehouse_id', $warehouse->id)
            ->lockForUpdate()
            ->first();

        if (! $stock) {
            $stock = PartStock::create([
                'part_id'      => $part->id,
                'warehouse_id' => $warehouse->id,
                'quantity'     => 0,
            ]);
        }

        return $stock;
    }

    private function notifyLowStock(Part $part): void
    {
        $managers = User::whereIn('role', ['admin', 'supervisor'])
            ->where('is_active', true)->get();
        foreach ($managers as $manager) {
            $manager->notify(new LowStockNotification($part));
        }
    }

    private function assertPositive(float $qty): void
    {
        if ($qty <= 0) {
            throw ValidationException::withMessages(['quantity' => 'الكمية يجب أن تكون أكبر من صفر.']);
        }
    }
}
