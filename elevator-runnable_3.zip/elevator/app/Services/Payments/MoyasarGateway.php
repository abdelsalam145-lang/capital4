<?php

namespace App\Services\Payments;

use App\Models\Payment;
use Illuminate\Support\Facades\Http;

/**
 * مثال تطبيقي لبوابة Moyasar (شائعة في السعودية).
 * ملاحظة: المبالغ لدى Moyasar بالهللات (×100). يُضبط المفتاح في config/services.php.
 *
 * نفس النمط ينطبق على Tap/PayTabs بتغيير نقاط النهاية فقط.
 */
class MoyasarGateway implements PaymentGateway
{
    private string $secretKey;
    private string $baseUrl = 'https://api.moyasar.com/v1';

    public function __construct()
    {
        $this->secretKey = (string) config('services.moyasar.secret_key');
    }

    public function initiate(Payment $payment, string $callbackUrl): array
    {
        // ملاحظة عملية: الدفع غالباً يبدأ من واجهة العميل عبر Moyasar.js،
        // وهذا المسار للتحقق من الخادم. هنا نُنشئ سجل نية الدفع.
        $response = Http::withBasicAuth($this->secretKey, '')
            ->post("{$this->baseUrl}/payments", [
                'amount'      => (int) round($payment->amount * 100), // هللات
                'currency'    => $payment->currency,
                'description' => "دفع فاتورة {$payment->invoice->reference}",
                'callback_url'=> $callbackUrl,
                'metadata'    => ['payment_id' => $payment->id],
            ])
            ->throw()
            ->json();

        return [
            'redirect_url'       => $response['source']['transaction_url'] ?? $callbackUrl,
            'gateway_payment_id' => $response['id'],
        ];
    }

    public function verify(string $gatewayPaymentId): array
    {
        $response = Http::withBasicAuth($this->secretKey, '')
            ->get("{$this->baseUrl}/payments/{$gatewayPaymentId}")
            ->throw()
            ->json();

        // Moyasar: paid = ناجح
        $status = match ($response['status'] ?? '') {
            'paid'              => 'completed',
            'failed', 'voided'  => 'failed',
            default             => 'pending',
        };

        return ['status' => $status, 'raw' => $response];
    }

    public function name(): string
    {
        return 'moyasar';
    }
}
