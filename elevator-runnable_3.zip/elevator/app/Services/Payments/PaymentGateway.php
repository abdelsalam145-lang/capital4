<?php

namespace App\Services\Payments;

use App\Models\Payment;

/**
 * واجهة بوابة الدفع: نفّذ هذه الواجهة لأي مزوّد (Moyasar / Tap / PayTabs).
 * هذا يفصل منطق النظام عن المزوّد، فيمكن تبديله دون تغيير باقي الكود.
 */
interface PaymentGateway
{
    /**
     * بدء عملية دفع. تُعيد مصفوفة فيها رابط الدفع ومعرّف العملية.
     * @return array{redirect_url:string, gateway_payment_id:string}
     */
    public function initiate(Payment $payment, string $callbackUrl): array;

    /**
     * التحقق من حالة الدفعة لدى البوابة (يُستدعى عند عودة العميل أو من webhook).
     * @return array{status:string, raw:array}  status: completed|failed|pending
     */
    public function verify(string $gatewayPaymentId): array;

    public function name(): string;
}
