<?php

namespace App\Services;

use App\Models\MaintenanceRequest;
use App\Models\User;
use App\Models\Elevator;
use App\Notifications\RequestAssignedNotification;
use App\Notifications\RequestCompletedNotification;
use App\Notifications\NewRequestNotification;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * خدمة إدارة الطلبات: كل تغيير في حالة الطلب يمرّ من هنا
 * لضمان تسجيل السجلات وإرسال الإشعارات بشكل موحّد.
 *
 * دورة الحالة المسموحة:
 *  new → assigned → in_progress → completed → closed
 *  ويمكن الإلغاء (cancelled) من أي حالة مفتوحة.
 */
class RequestService
{
    /** الانتقالات المسموحة بين الحالات */
    private const TRANSITIONS = [
        'new'         => ['assigned', 'cancelled'],
        'assigned'    => ['in_progress', 'assigned', 'cancelled'], // assigned→assigned = إعادة تعيين
        'in_progress' => ['completed', 'cancelled'],
        'completed'   => ['closed'],
        'closed'      => [],
        'cancelled'   => [],
    ];

    /**
     * إنشاء طلب جديد.
     * يصلح لكلا الحالتين: العميل يرفع طلبه، أو موظف ينشئه نيابةً عن عميل.
     */
    public function create(array $data, User $creator): MaintenanceRequest
    {
        $elevator = Elevator::with('building')->findOrFail($data['elevator_id']);

        // إذا كان المُنشئ عميلاً، نتأكد أن المصعد يخصّه فعلاً (حماية)
        if ($creator->isCustomer()) {
            if ($elevator->building->customer_id !== $creator->customer_id) {
                throw ValidationException::withMessages([
                    'elevator_id' => 'هذا المصعد لا يتبع حسابك.',
                ]);
            }
        }

        return DB::transaction(function () use ($data, $creator, $elevator) {
            $request = MaintenanceRequest::create([
                'type'        => $data['type'],            // maintenance | fault | inspection
                'elevator_id' => $elevator->id,
                'customer_id' => $elevator->building->customer_id,
                'created_by'  => $creator->id,
                'title'       => $data['title'],
                'description' => $data['description'] ?? null,
                'priority'    => $data['priority'] ?? 'normal',
                'status'      => 'new',
            ]);

            $this->logStatus($request, $creator, null, 'new', 'تم إنشاء الطلب');

            // إشعار المدير والمشرفين باستقبال طلب جديد
            $managers = User::whereIn('role', ['admin', 'supervisor'])->where('is_active', true)->get();
            foreach ($managers as $manager) {
                $manager->notify(new NewRequestNotification($request));
            }

            return $request->fresh();
        });
    }

    /**
     * تعيين فني للطلب. يقوم به المدير أو أي من المشرفين الثلاثة.
     * يمكن استخدامها أيضاً لإعادة التعيين لفني آخر.
     */
    public function assignTechnician(MaintenanceRequest $request, User $technician, User $actor, ?string $scheduledAt = null): MaintenanceRequest
    {
        if (! $actor->canManageRequests()) {
            throw ValidationException::withMessages([
                'authorization' => 'فقط المدير أو المشرفون يمكنهم تعيين الفنيين.',
            ]);
        }

        if (! $technician->isTechnician()) {
            throw ValidationException::withMessages([
                'technician' => 'المستخدم المختار ليس فنياً.',
            ]);
        }

        $this->guardTransition($request->status, 'assigned');

        return DB::transaction(function () use ($request, $technician, $actor, $scheduledAt) {
            $from = $request->status;
            $request->update([
                'assigned_technician_id' => $technician->id,
                'assigned_by'            => $actor->id,
                'assigned_at'            => now(),
                'scheduled_at'           => $scheduledAt,
                'status'                 => 'assigned',
            ]);

            $this->logStatus($request, $actor, $from, 'assigned',
                "تم تعيين الفني: {$technician->name}");

            // إشعار الفني بالمهمة الجديدة
            $technician->notify(new RequestAssignedNotification($request));

            return $request->fresh();
        });
    }

    /** الفني يبدأ العمل على الطلب */
    public function start(MaintenanceRequest $request, User $technician): MaintenanceRequest
    {
        $this->guardOwnership($request, $technician);
        $this->guardTransition($request->status, 'in_progress');

        $from = $request->status;
        $request->update(['status' => 'in_progress']);
        $this->logStatus($request, $technician, $from, 'in_progress', 'بدأ الفني العمل');

        return $request->fresh();
    }

    /**
     * الفني ينهي الطلب. عند الإنهاء يُرسل للعميل إشعار لتقييم الفني.
     */
    public function complete(MaintenanceRequest $request, User $technician, ?string $notes = null): MaintenanceRequest
    {
        $this->guardOwnership($request, $technician);
        $this->guardTransition($request->status, 'completed');

        return DB::transaction(function () use ($request, $technician, $notes) {
            $from = $request->status;
            $request->update([
                'status'           => 'completed',
                'completed_at'     => now(),
                'resolution_notes' => $notes,
            ]);

            $this->logStatus($request, $technician, $from, 'completed', $notes ?? 'تم إنهاء الطلب');

            // إرسال طلب التقييم للعميل (عبر حساب العميل إن وُجد)
            $customerUser = $request->customer->userAccount;
            if ($customerUser) {
                $customerUser->notify(new RequestCompletedNotification($request));
            }

            return $request->fresh();
        });
    }

    /**
     * إغلاق الطلب بعد تقييم العميل (يُستدعى من خدمة التقييم).
     */
    public function close(MaintenanceRequest $request, User $actor): MaintenanceRequest
    {
        $this->guardTransition($request->status, 'closed');

        $from = $request->status;
        $request->update(['status' => 'closed']);
        $this->logStatus($request, $actor, $from, 'closed', 'تم إغلاق الطلب بعد التقييم');

        return $request->fresh();
    }

    /** إلغاء الطلب */
    public function cancel(MaintenanceRequest $request, User $actor, string $reason): MaintenanceRequest
    {
        $this->guardTransition($request->status, 'cancelled');

        $from = $request->status;
        $request->update(['status' => 'cancelled']);
        $this->logStatus($request, $actor, $from, 'cancelled', $reason);

        return $request->fresh();
    }

    // ===== أدوات داخلية =====

    private function guardTransition(string $from, string $to): void
    {
        if (! in_array($to, self::TRANSITIONS[$from] ?? [])) {
            throw ValidationException::withMessages([
                'status' => "لا يمكن نقل الطلب من حالة ({$from}) إلى ({$to}).",
            ]);
        }
    }

    private function guardOwnership(MaintenanceRequest $request, User $technician): void
    {
        if ($request->assigned_technician_id !== $technician->id) {
            throw ValidationException::withMessages([
                'authorization' => 'هذا الطلب غير مسند إليك.',
            ]);
        }
    }

    private function logStatus(MaintenanceRequest $request, User $user, ?string $from, string $to, ?string $note): void
    {
        $request->statusLogs()->create([
            'user_id'     => $user->id,
            'from_status' => $from,
            'to_status'   => $to,
            'note'        => $note,
        ]);
    }
}
