<?php

namespace App\Services;

use App\Models\Contract;
use App\Models\Invoice;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

/**
 * خدمة الفواتير: إنشاء الفواتير وحساب قيمها (الضريبة 15%) وإدارة حالتها.
 */
class InvoiceService
{
    /**
     * إنشاء فاتورة مع بنودها وحساب الإجماليات.
     *
     * @param array $items كل عنصر: ['description'=>..,'quantity'=>..,'unit_price'=>..]
     */
    public function create(array $data, array $items): Invoice
    {
        return DB::transaction(function () use ($data, $items) {
            $invoice = Invoice::create([
                'customer_id'            => $data['customer_id'],
                'contract_id'            => $data['contract_id'] ?? null,
                'maintenance_request_id' => $data['maintenance_request_id'] ?? null,
                'issue_date'             => $data['issue_date'] ?? now()->toDateString(),
                'due_date'               => $data['due_date'] ?? now()->addDays(30)->toDateString(),
                'tax_rate'               => $data['tax_rate'] ?? 15.00,
                'discount'               => $data['discount'] ?? 0,
                'status'                 => 'draft',
                'notes'                  => $data['notes'] ?? null,
            ]);

            foreach ($items as $item) {
                $invoice->items()->create([
                    'description' => $item['description'],
                    'quantity'    => $item['quantity'] ?? 1,
                    'unit_price'  => $item['unit_price'] ?? 0,
                ]);
            }

            return $this->recalculate($invoice);
        });
    }

    /**
     * إعادة حساب إجماليات الفاتورة من بنودها ومن مدفوعاتها.
     * subtotal → خصم → ضريبة على الصافي → الإجمالي.
     */
    public function recalculate(Invoice $invoice): Invoice
    {
        $invoice->loadMissing('items');

        $subtotal   = round($invoice->items->sum('line_total'), 2);
        $afterDisc  = max(0, $subtotal - (float) $invoice->discount);
        $taxAmount  = round($afterDisc * ((float) $invoice->tax_rate / 100), 2);
        $total      = round($afterDisc + $taxAmount, 2);

        // المدفوع = مجموع الدفعات المكتملة فقط
        $paid = round($invoice->payments()->where('status', 'completed')->sum('amount'), 2);

        $invoice->update([
            'subtotal'    => $subtotal,
            'tax_amount'  => $taxAmount,
            'total'       => $total,
            'amount_paid' => $paid,
            'status'      => $this->resolveStatus($invoice, $total, $paid),
        ]);

        return $invoice->fresh();
    }

    /** اشتقاق حالة الفاتورة بناءً على المدفوع والاستحقاق */
    private function resolveStatus(Invoice $invoice, float $total, float $paid): string
    {
        if (in_array($invoice->status, ['draft', 'cancelled'])) {
            // المسودّة تبقى مسودّة حتى تُعتمد؛ الملغاة تبقى ملغاة
            if ($invoice->status === 'cancelled') return 'cancelled';
            if ($invoice->status === 'draft' && $paid <= 0) return 'draft';
        }

        if ($paid <= 0) {
            return $invoice->due_date && $invoice->due_date->isPast() ? 'overdue' : 'unpaid';
        }
        if ($paid < $total) {
            return 'partially_paid';
        }
        return 'paid';
    }

    /** اعتماد فاتورة مسودّة (تتحول لـ unpaid) */
    public function issue(Invoice $invoice): Invoice
    {
        if ($invoice->status === 'draft') {
            $invoice->update(['status' => 'unpaid']);
        }
        return $this->recalculate($invoice);
    }

    /**
     * توليد فاتورة دورية من عقد فعّال.
     * تحسب قيمة الدورة من قيمة العقد وتضبط تاريخ الاستحقاق.
     */
    public function generateFromContract(Contract $contract, ?Carbon $issueDate = null): Invoice
    {
        $issueDate ??= now();

        $invoice = $this->create([
            'customer_id' => $contract->customer_id,
            'contract_id' => $contract->id,
            'issue_date'  => $issueDate->toDateString(),
            'due_date'    => $issueDate->copy()->addDays(15)->toDateString(),
            'tax_rate'    => 15.00,
            'notes'       => "فاتورة عقد صيانة {$contract->reference} - دورة {$contract->billing_cycle}",
        ], [[
            'description' => "قيمة عقد الصيانة ({$contract->type}) للفترة من {$issueDate->toDateString()}",
            'quantity'    => 1,
            'unit_price'  => $contract->value,
        ]]);

        return $this->issue($invoice);
    }

    public function cancel(Invoice $invoice): Invoice
    {
        $invoice->update(['status' => 'cancelled']);
        return $invoice->fresh();
    }
}
