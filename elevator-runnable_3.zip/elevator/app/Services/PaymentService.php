<?php

namespace App\Services;

use App\Models\Invoice;
use App\Models\Payment;
use App\Models\User;
use App\Services\Payments\PaymentGateway;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * خدمة المدفوعات: تسجّل الدفعات (يدوية أو إلكترونية) وتحدّث حالة الفاتورة.
 */
class PaymentService
{
    public function __construct(private InvoiceService $invoices) {}

    /**
     * تسجيل دفعة يدوية (نقدي / تحويل / شيك) بمعرفة موظف.
     * تُحتسب مباشرة كمكتملة وتُحدّث الفاتورة.
     */
    public function recordManual(Invoice $invoice, array $data, User $actor): Payment
    {
        $this->guardPayable($invoice, (float) $data['amount']);

        return DB::transaction(function () use ($invoice, $data, $actor) {
            $payment = Payment::create([
                'invoice_id'  => $invoice->id,
                'customer_id' => $invoice->customer_id,
                'amount'      => $data['amount'],
                'method'      => $data['method'],          // cash | bank_transfer | cheque
                'status'      => 'completed',
                'recorded_by' => $actor->id,
                'paid_at'     => now(),
                'notes'       => $data['notes'] ?? null,
            ]);

            $this->invoices->recalculate($invoice);
            return $payment->fresh();
        });
    }

    /**
     * بدء دفعة إلكترونية عبر بوابة. تُنشئ سجل دفعة pending وتُعيد رابط الدفع.
     */
    public function initiateOnline(Invoice $invoice, float $amount, PaymentGateway $gateway, string $callbackUrl): array
    {
        $this->guardPayable($invoice, $amount);

        $payment = Payment::create([
            'invoice_id'  => $invoice->id,
            'customer_id' => $invoice->customer_id,
            'amount'      => $amount,
            'method'      => 'online_gateway',
            'status'      => 'pending',
            'gateway'     => $gateway->name(),
        ]);

        $result = $gateway->initiate($payment, $callbackUrl);

        $payment->update(['gateway_payment_id' => $result['gateway_payment_id']]);

        return [
            'payment_id'   => $payment->id,
            'redirect_url' => $result['redirect_url'],
        ];
    }

    /**
     * تأكيد دفعة إلكترونية بعد التحقق من البوابة (callback / webhook).
     */
    public function confirmOnline(Payment $payment, PaymentGateway $gateway): Payment
    {
        if ($payment->status === 'completed') {
            return $payment; // سبق تأكيدها (حماية من التكرار)
        }

        $result = $gateway->verify($payment->gateway_payment_id);

        return DB::transaction(function () use ($payment, $result) {
            $payment->update([
                'status'           => $result['status'],
                'gateway_response' => $result['raw'],
                'paid_at'          => $result['status'] === 'completed' ? now() : null,
            ]);

            if ($result['status'] === 'completed') {
                $this->invoices->recalculate($payment->invoice);
            }

            return $payment->fresh();
        });
    }

    /** التحقق من إمكانية الدفع ومن أن المبلغ لا يتجاوز المتبقّي */
    private function guardPayable(Invoice $invoice, float $amount): void
    {
        if (in_array($invoice->status, ['paid', 'cancelled', 'draft'])) {
            throw ValidationException::withMessages([
                'invoice' => 'لا يمكن الدفع لهذه الفاتورة في حالتها الحالية.',
            ]);
        }
        if ($amount <= 0) {
            throw ValidationException::withMessages(['amount' => 'المبلغ غير صحيح.']);
        }
        if ($amount > $invoice->balance() + 0.01) {
            throw ValidationException::withMessages([
                'amount' => "المبلغ يتجاوز المتبقّي على الفاتورة ({$invoice->balance()}).",
            ]);
        }
    }
}
