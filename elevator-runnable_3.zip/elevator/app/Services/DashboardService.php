<?php

namespace App\Services;

use App\Models\MaintenanceRequest;
use App\Models\Invoice;
use App\Models\Payment;
use App\Models\Contract;
use App\Models\Part;
use App\Models\PartUsage;
use App\Models\User;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

/**
 * خدمة التقارير: استعلامات مُحسَّنة (تجميع على مستوى قاعدة البيانات)
 * تغذّي لوحة المؤشرات. كل دالة مستقلة ليُعاد استخدامها في API أو تصدير.
 */
class DashboardService
{
    /** بطاقات النظرة العامة (الأرقام الكبيرة أعلى اللوحة) */
    public function overview(): array
    {
        $startOfMonth = now()->startOfMonth();

        return [
            'open_requests'      => MaintenanceRequest::open()->count(),
            'unassigned'         => MaintenanceRequest::where('status', 'new')->count(),
            'in_progress'        => MaintenanceRequest::where('status', 'in_progress')->count(),
            'completed_this_month' => MaintenanceRequest::where('status', 'closed')
                                        ->where('completed_at', '>=', $startOfMonth)->count(),

            'revenue_this_month' => round((float) Payment::where('status', 'completed')
                                        ->where('paid_at', '>=', $startOfMonth)->sum('amount'), 2),
            'outstanding'        => round((float) Invoice::unpaid()
                                        ->selectRaw('SUM(total - amount_paid) as bal')->value('bal') ?? 0, 2),
            'overdue_invoices'   => Invoice::where('status', 'overdue')->count(),

            'active_contracts'   => Contract::where('status', 'active')->count(),
            'contracts_expiring' => Contract::where('status', 'active')
                                        ->whereBetween('end_date', [now(), now()->addDays(30)])->count(),

            'low_stock_parts'    => Part::lowStock()->count(),
        ];
    }

    /** الطلبات حسب الحالة (لرسم دائري) */
    public function requestsByStatus(): array
    {
        return MaintenanceRequest::select('status', DB::raw('count(*) as count'))
            ->groupBy('status')->pluck('count', 'status')->toArray();
    }

    /** الطلبات حسب النوع (صيانة/عطل/معاينة) */
    public function requestsByType(): array
    {
        return MaintenanceRequest::select('type', DB::raw('count(*) as count'))
            ->groupBy('type')->pluck('count', 'type')->toArray();
    }

    /** اتجاه الطلبات شهرياً خلال آخر 12 شهراً (لرسم خطّي) */
    public function requestsTrend(int $months = 12): array
    {
        $from = now()->startOfMonth()->subMonths($months - 1);

        $rows = MaintenanceRequest::where('created_at', '>=', $from)
            ->select(
                DB::raw("to_char(created_at, 'YYYY-MM') as ym"),
                DB::raw('count(*) as count')
            )
            ->groupBy('ym')->orderBy('ym')->pluck('count', 'ym')->toArray();

        // ملء الأشهر الفارغة بصفر
        $result = [];
        for ($i = 0; $i < $months; $i++) {
            $key = $from->copy()->addMonths($i)->format('Y-m');
            $result[$key] = $rows[$key] ?? 0;
        }
        return $result;
    }

    /**
     * الأعطال المتكررة لكل مصعد: أيّ مصعد يحتاج اهتماماً (أو استبدالاً).
     */
    public function topProblematicElevators(int $limit = 10): array
    {
        return MaintenanceRequest::where('type', 'fault')
            ->select('elevator_id', DB::raw('count(*) as faults'))
            ->with(['elevator.building.customer'])
            ->groupBy('elevator_id')
            ->orderByDesc('faults')
            ->limit($limit)
            ->get()
            ->map(fn ($r) => [
                'elevator_id' => $r->elevator_id,
                'label'       => $r->elevator?->label,
                'brand'       => $r->elevator?->brand,
                'building'    => $r->elevator?->building?->name,
                'customer'    => $r->elevator?->building?->customer?->name,
                'faults'      => (int) $r->faults,
            ])->toArray();
    }

    /**
     * أداء الفنيين: عدد المنجز، متوسط التقييم، متوسط زمن الإنجاز (بالساعات).
     */
    public function technicianPerformance(): array
    {
        $technicians = User::where('role', 'technician')->get();

        return $technicians->map(function (User $tech) {
            $completed = MaintenanceRequest::forTechnician($tech->id)
                ->whereIn('status', ['completed', 'closed']);

            $completedCount = (clone $completed)->count();

            // متوسط زمن الإنجاز: من التعيين حتى الإكمال (ساعات)
            $avgHours = (clone $completed)
                ->whereNotNull('assigned_at')->whereNotNull('completed_at')
                ->select(DB::raw('AVG(EXTRACT(EPOCH FROM (completed_at - assigned_at))/3600) as h'))
                ->value('h');

            $avgRating = DB::table('technician_ratings')
                ->where('technician_id', $tech->id)->avg('rating');

            return [
                'technician_id'   => $tech->id,
                'name'            => $tech->name,
                'completed'       => $completedCount,
                'open'            => MaintenanceRequest::forTechnician($tech->id)->open()->count(),
                'avg_rating'      => $avgRating ? round((float) $avgRating, 2) : null,
                'avg_hours'       => $avgHours ? round((float) $avgHours, 1) : null,
            ];
        })->sortByDesc('completed')->values()->toArray();
    }

    /** الإيرادات الشهرية خلال آخر 12 شهراً (مدفوعات مكتملة فعلاً) */
    public function revenueTrend(int $months = 12): array
    {
        $from = now()->startOfMonth()->subMonths($months - 1);

        $rows = Payment::where('status', 'completed')
            ->where('paid_at', '>=', $from)
            ->select(
                DB::raw("to_char(paid_at, 'YYYY-MM') as ym"),
                DB::raw('SUM(amount) as total')
            )
            ->groupBy('ym')->orderBy('ym')->pluck('total', 'ym')->toArray();

        $result = [];
        for ($i = 0; $i < $months; $i++) {
            $key = $from->copy()->addMonths($i)->format('Y-m');
            $result[$key] = round((float) ($rows[$key] ?? 0), 2);
        }
        return $result;
    }

    /** ملخّص مالي: المفوتر، المحصّل، المتبقّي، نسبة التحصيل */
    public function financialSummary(): array
    {
        $invoiced  = (float) Invoice::whereNotIn('status', ['draft', 'cancelled'])->sum('total');
        $collected = (float) Invoice::sum('amount_paid');
        $outstanding = round($invoiced - $collected, 2);

        return [
            'total_invoiced'   => round($invoiced, 2),
            'total_collected'  => round($collected, 2),
            'outstanding'      => max(0, $outstanding),
            'collection_rate'  => $invoiced > 0 ? round($collected / $invoiced * 100, 1) : 0,
        ];
    }

    /** القطع الأكثر استهلاكاً (لتخطيط المشتريات) */
    public function topConsumedParts(int $limit = 10): array
    {
        return PartUsage::select('part_id', DB::raw('SUM(quantity) as qty'))
            ->with('part:id,sku,name')
            ->groupBy('part_id')
            ->orderByDesc('qty')
            ->limit($limit)
            ->get()
            ->map(fn ($u) => [
                'part_id' => $u->part_id,
                'sku'     => $u->part?->sku,
                'name'    => $u->part?->name,
                'qty'     => (float) $u->qty,
            ])->toArray();
    }

    /** القطع التي تحتاج إعادة طلب الآن */
    public function lowStockParts(): array
    {
        return Part::lowStock()
            ->select('id', 'sku', 'name', 'quantity_on_hand', 'reorder_level')
            ->orderBy('quantity_on_hand')
            ->get()->toArray();
    }
}
